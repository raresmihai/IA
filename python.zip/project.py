import string
import urllib
from collections import Counter
import operator

import duckduckgo
from google import google
from bs4 import BeautifulSoup


def get_best_phrase(text, key_words):
    if text == '':
        return ''
    # list of thrases
    phrases1 = []
    # string for storing a phrase ,appended to phrases1 and reused for next phrase
    phrase1 = ''
    # list stores phrases,a phrase as a list of words
    phrases2 = []
    # list of dictionaries. for each phrase create a dictionary of words
    dict1 = []
    # list of number of occurences of keywords in phrase
    dict2 = []
    for i in text:
        # nu am folosit punctuation pentru ca ala vede si paranteza si alte caractere ca punctuatie
        # ex:Abraham Lincoln (Listeni/ˈeɪbrəhæm ˈlɪŋkən/; February 12, 1809 – April 15, 1865) was an ...
        # folosing punctuation imi ia Abraham lincon o fraza,si was an alta fraza si imi exclude cea mai alegere.
        # si imi exclude cea mai buna fraza
        if i not in '.' or i not in '?' or i not in '!':
            phrase1 += i
        else:
            phrases1.append(phrase1)
            phrase1 = ''

    for i in phrases1:
        temp = []
        phrase2 = i.split()
        for j in phrase2:
            temp.append(j)

        phrases2.append(temp)

    for i in range(len(phrases2)):
        dict1.append(dict(Counter(phrases2[i])))
    # max occurences
    maxx = 0

    for i in dict1:
        for j in key_words:
            if j in i:
                maxx += 1
        dict2.append(maxx)
        maxx = 0
    index, value = max(enumerate(dict2), key=operator.itemgetter(1))
    print str(' '.join(phrases2[index]).encode('utf-8').strip())
    print value
    return str(' '.join(phrases2[index]).encode('utf-8').strip())


def get_text_from_html_page(url):
    if url == '':
        return ''
    html = urllib.urlopen(url).read()
    soup = BeautifulSoup(html, 'html.parser')

    # kill all script and style elements
    for script in soup(["script", "style"]):
        script.extract()  # rip it out

    # get text
    text = soup.get_text()

    # break into lines and remove leading and trailing space on each
    lines = (line.strip() for line in text.splitlines())
    # break multi-headlines into a line each
    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
    # drop blank lines
    text = '\n'.join(chunk for chunk in chunks if chunk)

    # print(text)
    return text


def duckduckgo_result(search_string):
    try:
        search_results = duckduckgo.query(search_string)
    except:
        return ''
    print search_results.abstract.url
    url = ''
    for i in search_results.abstract.url:
        if i in '(':
            break
        else:
            url += i
    return url


def google_results(search_string):
    try:
        search_results = google.search(search_string, 1)
    except:
        return ''
    return search_results


def return_search_on_google(search_type, input_type, words_synonyms, key_words):
    answer = ''
    search_string = ''
    all_words = []
    # am gasit pe google niste tips cum sa faci cautarea.
    # daca pui cuvintele in " ",ti le cauta ca cuvinte intregi,daca pui OR intre ele,cauta ambele variante
    for i, j in words_synonyms:
        search_string += '"' + i + '" OR ' + '"' + j + '" '
        all_words.append(i)
        all_words.append(j)
    for i in key_words:
        search_string += ' "' + i + '"'
        all_words.append(i)

    print 'search string ='
    print search_string
    temp = all_words[:]

    search_results_google = google_results(search_string)
    # search_results_google = [] aici decomentam si comentam apelul de google ca sa vad cum merge duckduckgo
    if search_results_google:
        print 'google'
        answer += get_best_phrase(get_text_from_html_page(search_results_google[0].link), all_words)
    if answer == '':
        print 'duckduckgo'
        temp.insert(0, 'dummy data')
        # duckduckgo nu gaseste raspuns daca sunt prea multe cuvinte,in comparatie cu google
        # de aceea am iterat si fac un call la duckduckgo excluzand cate un cuvant pana primesc un raspuns
        while answer == '' and temp:
            del temp[0]
            str = ' '.join(temp)
            print str
            answer += get_best_phrase(
                get_text_from_html_page(duckduckgo_result(str)),
                all_words)
    print answer


return_search_on_google(0, True, [('president', 'leader'), ('lawyer', 'politician')], ['abraham', 'lincoln'])
